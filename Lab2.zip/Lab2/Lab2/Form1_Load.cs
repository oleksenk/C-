﻿namespace Lab2
{
    internal class Form1_Load
    {
    }
}